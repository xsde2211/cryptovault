// App.js — CryptoVault v2 Root Entry
// CRITICAL: Polyfill imports must be in this exact order

import 'react-native-get-random-values'
import '@ethersproject/shims'
import 'react-native-url-polyfill/auto'

import { Buffer } from 'buffer'
global.Buffer = Buffer
global.process = require('process')

// ─────────────────────────────────────────────────────────────
import React from 'react'
import { View, Text, StyleSheet, Platform } from 'react-native'
import { StatusBar } from 'expo-status-bar'
import { SafeAreaProvider } from 'react-native-safe-area-context'
import Toast from 'react-native-toast-message'
import { AppProvider } from './src/context/AppContext'
import AppNavigator from './src/navigation/AppNavigator'
import { COLORS, RADIUS } from './src/utils/theme'

// ── Toast config ──────────────────────────────────────────────
const TOAST_CFG = {
  success: { bg: 'rgba(16,185,129,0.15)',  border: 'rgba(16,185,129,0.35)',  icon: '✅' },
  error:   { bg: 'rgba(244,63,94,0.15)',   border: 'rgba(244,63,94,0.35)',   icon: '❌' },
  info:    { bg: 'rgba(124,111,247,0.15)', border: 'rgba(124,111,247,0.35)', icon: 'ℹ️' },
  warning: { bg: 'rgba(245,158,11,0.15)',  border: 'rgba(245,158,11,0.35)',  icon: '⚠️' },
}

function ToastComp({ type, text1, text2 }) {
  const s = TOAST_CFG[type] || TOAST_CFG.info
  return (
    <View style={[ts.toast, { backgroundColor: s.bg, borderColor: s.border }]}>
      <Text style={{ fontSize: 18 }}>{s.icon}</Text>
      <View style={{ flex: 1 }}>
        {text1 && <Text style={ts.t1}>{text1}</Text>}
        {text2 && <Text style={ts.t2}>{text2}</Text>}
      </View>
    </View>
  )
}

const toastConfig = {
  success: (p) => <ToastComp type="success" {...p} />,
  error:   (p) => <ToastComp type="error"   {...p} />,
  info:    (p) => <ToastComp type="info"    {...p} />,
  warning: (p) => <ToastComp type="warning" {...p} />,
}

const ts = StyleSheet.create({
  toast: {
    flexDirection: 'row', alignItems: 'center', gap: 10,
    marginHorizontal: 16, paddingVertical: 12, paddingHorizontal: 16,
    borderRadius: RADIUS.md, borderWidth: 1,
    shadowColor: '#000', shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.25, shadowRadius: 8, elevation: 6,
  },
  t1: { color: COLORS.text,      fontWeight: '700', fontSize: 14 },
  t2: { color: COLORS.textMuted, fontSize: 12, marginTop: 1 },
})

// ── Root ──────────────────────────────────────────────────────
export default function App() {
  return (
    <SafeAreaProvider>
      <AppProvider>
        <StatusBar style="light" backgroundColor={COLORS.bg} />
        <AppNavigator />
        <Toast
          config={toastConfig}
          topOffset={Platform.OS === 'ios' ? 56 : 40}
          visibilityTime={3000}
        />
      </AppProvider>
    </SafeAreaProvider>
  )
}
