// src/navigation/AppNavigator.js
import React from 'react'
import { View, Text, Platform } from 'react-native'
import { NavigationContainer } from '@react-navigation/native'
import { createNativeStackNavigator }  from '@react-navigation/native-stack'
import { createBottomTabNavigator }    from '@react-navigation/bottom-tabs'

import { useApp }   from '../context/AppContext'
import { COLORS }   from '../utils/theme'
import { Spinner }  from '../components/UI'

// ── Auth ────────────────────────────────────────────────────────
import LoginScreen    from '../screens/auth/LoginScreen'
import SignupScreen   from '../screens/auth/SignupScreen'

// ── Main Tabs ───────────────────────────────────────────────────
import DashboardScreen  from '../screens/main/DashboardScreen'
import SwapScreen       from '../screens/main/SwapScreen'
import WatchlistScreen  from '../screens/main/WatchlistScreen'
import SettingsScreen   from '../screens/main/SettingsScreen'

// ── Stack Screens ───────────────────────────────────────────────
import SendScreen         from '../screens/main/SendScreen'
import ReceiveScreen      from '../screens/main/ReceiveScreen'
import CreateWalletScreen from '../screens/wallet/CreateWalletScreen'
import ImportWalletScreen from '../screens/wallet/ImportWalletScreen'
import TokensScreen       from '../screens/main/TokensScreen'
import TransactionsScreen from '../screens/main/TransactionsScreen'
import NFTScreen          from '../screens/main/NFTScreen'

// ── New Feature Screens ─────────────────────────────────────────
import TronWalletScreen   from '../screens/tron/TronWalletScreen'
import VirtualCardScreen  from '../screens/vcc/VirtualCardScreen'
import PhysicalCardScreen from '../screens/vcc/PhysicalCardScreen'
import KYCScreen          from '../screens/kyc/KYCScreen'
import P2PScreen          from '../screens/p2p/P2PScreen'
import MerchantScreen     from '../screens/p2p/MerchantScreen'

const Stack = createNativeStackNavigator()
const Tab   = createBottomTabNavigator()

// ── Tab icon ────────────────────────────────────────────────────
const TabIcon = ({ emoji, label, focused }) => (
  <View style={{ alignItems: 'center', paddingTop: 4, paddingBottom: 2 }}>
    <Text style={{ fontSize: 20, opacity: focused ? 1 : 0.4 }}>{emoji}</Text>
    <Text style={{
      fontSize: 9, marginTop: 2, fontWeight: focused ? '700' : '500', letterSpacing: 0.2,
      color: focused ? COLORS.accent : COLORS.textDim,
    }}>
      {label}
    </Text>
  </View>
)

// ── Header options ───────────────────────────────────────────────
const headerOpts = (title) => ({
  headerShown:     true,
  title,
  headerStyle:       { backgroundColor: COLORS.bg },
  headerTintColor:   COLORS.text,
  headerTitleStyle:  { fontWeight: '700', fontSize: 17 },
  headerBackTitle:   '',
  headerShadowVisible: false,
  contentStyle:      { backgroundColor: COLORS.bg },
})

// ── Main Tab Navigator ───────────────────────────────────────────
function MainTabs() {
  return (
    <Tab.Navigator
      screenOptions={{
        headerShown:     false,
        tabBarShowLabel: false,
        tabBarStyle: {
          backgroundColor: COLORS.surface,
          borderTopColor:  COLORS.border,
          borderTopWidth:  1,
          // Fix for proper height on all Android/iOS devices
          height: Platform.OS === 'ios' ? 82 : 64,
          paddingBottom: Platform.OS === 'ios' ? 22 : 8,
          paddingTop: 4,
        },
      }}
    >
      <Tab.Screen name="Dashboard" component={DashboardScreen}
        options={{ tabBarIcon: ({ focused }) => <TabIcon emoji="🏠" label="Home"    focused={focused} /> }} />
      <Tab.Screen name="Swap" component={SwapScreen}
        options={{ tabBarIcon: ({ focused }) => <TabIcon emoji="🔄" label="Swap"    focused={focused} /> }} />
      <Tab.Screen name="Cards" component={VirtualCardScreen}
        options={{ tabBarIcon: ({ focused }) => <TabIcon emoji="💳" label="Cards"   focused={focused} /> }} />
      <Tab.Screen name="P2P" component={P2PScreen}
        options={{ tabBarIcon: ({ focused }) => <TabIcon emoji="🏪" label="P2P"     focused={focused} /> }} />
      <Tab.Screen name="More" component={SettingsScreen}
        options={{ tabBarIcon: ({ focused }) => <TabIcon emoji="⚙️" label="More"    focused={focused} /> }} />
    </Tab.Navigator>
  )
}

// ── Root Navigator ───────────────────────────────────────────────
export default function AppNavigator() {
  const { user, authLoading } = useApp()

  if (authLoading) return (
    <View style={{ flex: 1, backgroundColor: COLORS.bg, justifyContent: 'center', alignItems: 'center' }}>
      <Spinner size="large" />
    </View>
  )

  return (
    <NavigationContainer>
      <Stack.Navigator screenOptions={{ headerShown: false, contentStyle: { backgroundColor: COLORS.bg } }}>
        {!user ? (
          <>
            <Stack.Screen name="Login"  component={LoginScreen}  />
            <Stack.Screen name="Signup" component={SignupScreen} />
          </>
        ) : (
          <>
            <Stack.Screen name="MainTabs"     component={MainTabs} />
            {/* Existing */}
            <Stack.Screen name="Send"         component={SendScreen}          options={headerOpts('Send')} />
            <Stack.Screen name="Receive"      component={ReceiveScreen}       options={headerOpts('Receive')} />
            <Stack.Screen name="Tokens"       component={TokensScreen}        options={headerOpts('Tokens')} />
            <Stack.Screen name="Transactions" component={TransactionsScreen}  options={headerOpts('History')} />
            <Stack.Screen name="NFTs"         component={NFTScreen}           options={headerOpts('NFTs')} />
            <Stack.Screen name="Watchlist"    component={WatchlistScreen}     options={headerOpts('Watchlist')} />
            <Stack.Screen name="CreateWallet" component={CreateWalletScreen}  options={headerOpts('New Wallet')} />
            <Stack.Screen name="ImportWallet" component={ImportWalletScreen}  options={headerOpts('Import Wallet')} />
            {/* New */}
            <Stack.Screen name="TRON"         component={TronWalletScreen}    options={headerOpts('TRON Wallet')} />
            <Stack.Screen name="KYC"          component={KYCScreen}           options={headerOpts('Identity Verification')} />
            <Stack.Screen name="PhysicalCard" component={PhysicalCardScreen}  options={headerOpts('Order Physical Card')} />
            <Stack.Screen name="Merchant"     component={MerchantScreen}      options={headerOpts('Merchant QR')} />
          </>
        )}
      </Stack.Navigator>
    </NavigationContainer>
  )
}
