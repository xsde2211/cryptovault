// src/screens/p2p/P2PScreen.js
import React, { useState, useEffect, useCallback } from 'react'
import {
  View, Text, ScrollView, TouchableOpacity, StyleSheet,
  Modal, RefreshControl, Alert as RNAlert,
} from 'react-native'
import { SafeAreaView } from 'react-native-safe-area-context'
import {
  getListings, createListing, createOrder,
  getMyOrders, updateOrderStatus,
} from '../../services/supabase/cardService'
import { useApp } from '../../context/AppContext'
import { COLORS, SPACING, RADIUS } from '../../utils/theme'
import { Card, PrimaryButton, SecondaryButton, Input, Alert, Spinner, Badge, InfoRow } from '../../components/UI'
import Toast from 'react-native-toast-message'

const CRYPTOS    = ['USDT', 'ETH', 'BNB', 'MATIC', 'TRX', 'BTC']
const FIATS      = ['USD', 'EUR', 'GBP', 'INR', 'AED', 'SGD', 'AUD']
const COUNTRIES  = ['US', 'GB', 'AE', 'IN', 'DE', 'SG', 'AU', 'CA', 'Other']
const PMETHODS   = ['Bank Transfer', 'PayPal', 'Wise', 'Revolut', 'UPI', 'Cash App', 'Venmo']
const FLAG       = { US: '🇺🇸', GB: '🇬🇧', AE: '🇦🇪', IN: '🇮🇳', DE: '🇩🇪', SG: '🇸🇬', AU: '🇦🇺', CA: '🇨🇦', Other: '🌍' }

export default function P2PScreen() {
  const { user, activeWallet } = useApp()
  const [tab,        setTab]        = useState('buy')       // buy | sell | myorders
  const [listings,   setListings]   = useState([])
  const [myOrders,   setMyOrders]   = useState([])
  const [loading,    setLoading]    = useState(true)
  const [refreshing, setRefreshing] = useState(false)
  const [filterCrypto, setFilterCrypto] = useState('USDT')
  const [filterCountry,setFilterCountry]= useState('')

  // Create listing modal
  const [showCreate, setShowCreate] = useState(false)
  const [lType,     setLType]     = useState('sell')
  const [lCrypto,   setLCrypto]   = useState('USDT')
  const [lFiat,     setLFiat]     = useState('USD')
  const [lAmount,   setLAmount]   = useState('')
  const [lPrice,    setLPrice]    = useState('')
  const [lMin,      setLMin]      = useState('10')
  const [lMax,      setLMax]      = useState('')
  const [lCountry,  setLCountry]  = useState('US')
  const [lPMs,      setLPMs]      = useState([])
  const [creating,  setCreating]  = useState(false)

  // Order modal
  const [orderModal, setOrderModal] = useState(false)
  const [orderListing, setOrderListing] = useState(null)
  const [orderAmt,   setOrderAmt]   = useState('')
  const [placingOrder, setPlacingOrder] = useState(false)

  const load = useCallback(async () => {
    setLoading(true)
    try {
      const [list, orders] = await Promise.all([
        getListings({ type: tab === 'myorders' ? undefined : tab, crypto: filterCrypto, country: filterCountry || undefined }),
        user ? getMyOrders(user.id) : [],
      ])
      setListings(list); setMyOrders(orders)
    } catch {} finally { setLoading(false); setRefreshing(false) }
  }, [tab, filterCrypto, filterCountry, user])

  useEffect(() => { load() }, [load])

  const handleCreate = async () => {
    if (!lAmount || !lPrice || !lMax) { Toast.show({ type: 'error', text1: 'Fill all required fields' }); return }
    if (lPMs.length === 0) { Toast.show({ type: 'error', text1: 'Select at least one payment method' }); return }
    setCreating(true)
    try {
      await createListing({
        type: lType, crypto: lCrypto, fiat_currency: lFiat,
        amount_crypto: parseFloat(lAmount), price_per_unit: parseFloat(lPrice),
        min_order: parseFloat(lMin), max_order: parseFloat(lMax),
        payment_methods: lPMs, country: lCountry,
      })
      setShowCreate(false); setLAmount(''); setLPrice(''); setLMax(''); setLPMs([])
      await load()
      Toast.show({ type: 'success', text1: 'Listing posted! ✅' })
    } catch (err) { Toast.show({ type: 'error', text1: err.message }) }
    setCreating(false)
  }

  const handleOrder = async () => {
    if (!orderAmt || parseFloat(orderAmt) < parseFloat(orderListing.min_order)) {
      Toast.show({ type: 'error', text1: `Min order: ${orderListing.min_order} ${orderListing.fiat_currency}` }); return
    }
    if (parseFloat(orderAmt) > parseFloat(orderListing.max_order)) {
      Toast.show({ type: 'error', text1: `Max order: ${orderListing.max_order} ${orderListing.fiat_currency}` }); return
    }
    setPlacingOrder(true)
    try {
      const cryptoAmt = parseFloat(orderAmt) / parseFloat(orderListing.price_per_unit)
      await createOrder({
        listing_id:   orderListing.id,
        buyer_id:     tab === 'buy' ? user.id : orderListing.user_id,
        seller_id:    tab === 'buy' ? orderListing.user_id : user.id,
        amount_crypto: cryptoAmt.toFixed(8),
        amount_fiat:  orderAmt,
        fiat_currency: orderListing.fiat_currency,
        escrow_locked: false,
        expires_at:   new Date(Date.now() + 30 * 60 * 1000).toISOString(),
      })
      setOrderModal(false); setOrderAmt('')
      await load()
      Toast.show({ type: 'success', text1: 'Order created! Lock escrow to proceed ✅' })
    } catch (err) { Toast.show({ type: 'error', text1: err.message }) }
    setPlacingOrder(false)
  }

  const handleEscrow = (order) => {
    RNAlert.alert(
      'Lock Escrow 🔐',
      `Lock ${order.amount_crypto} ${order.listing?.crypto || 'crypto'} in escrow?\n\nFunds will be held until the buyer confirms payment.`,
      [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Lock Escrow', onPress: async () => {
          try {
            await updateOrderStatus(order.id, 'escrow_locked', { escrow_locked: true })
            await load()
            Toast.show({ type: 'success', text1: 'Escrow locked 🔐' })
          } catch (err) { Toast.show({ type: 'error', text1: err.message }) }
        }},
      ]
    )
  }

  const handleRelease = (order) => {
    RNAlert.alert('Release Funds', 'Confirm you have received payment and release funds to buyer?', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Release', style: 'destructive', onPress: async () => {
        try {
          await updateOrderStatus(order.id, 'completed')
          await load()
          Toast.show({ type: 'success', text1: 'Funds released! Trade complete ✅' })
        } catch (err) { Toast.show({ type: 'error', text1: err.message }) }
      }},
    ])
  }

  const ListingCard = ({ listing }) => {
    const isBuy = listing.type === 'buy'
    const total = (listing.price_per_unit * listing.amount_crypto).toFixed(2)
    return (
      <Card style={styles.listingCard}>
        <View style={styles.listingHeader}>
          <View style={[styles.typeBadge, { backgroundColor: isBuy ? 'rgba(16,185,129,0.15)' : 'rgba(244,63,94,0.15)' }]}>
            <Text style={{ color: isBuy ? COLORS.success : COLORS.danger, fontWeight: '800', fontSize: 13 }}>{listing.type.toUpperCase()}</Text>
          </View>
          <Text style={styles.listingCrypto}>{listing.crypto}</Text>
          <Text style={styles.listingFlag}>{FLAG[listing.country] || '🌍'}</Text>
        </View>
        <View style={styles.listingBody}>
          <View>
            <Text style={styles.listingPrice}>
              {listing.fiat_currency} {parseFloat(listing.price_per_unit).toLocaleString()}
              <Text style={{ fontSize: 11, color: COLORS.textMuted }}> / {listing.crypto}</Text>
            </Text>
            <Text style={styles.listingMeta}>
              Available: {parseFloat(listing.amount_crypto).toFixed(4)} {listing.crypto} · ≈{listing.fiat_currency} {total}
            </Text>
            <Text style={styles.listingMeta}>
              Limit: {listing.fiat_currency} {listing.min_order}–{listing.max_order}
            </Text>
          </View>
          <TouchableOpacity
            style={[styles.tradeBtn, { backgroundColor: isBuy ? 'rgba(16,185,129,0.15)' : 'rgba(244,63,94,0.15)' }]}
            onPress={() => { setOrderListing(listing); setOrderModal(true) }}
          >
            <Text style={{ color: isBuy ? COLORS.success : COLORS.danger, fontWeight: '800' }}>
              {isBuy ? 'Sell' : 'Buy'}
            </Text>
          </TouchableOpacity>
        </View>
        {listing.payment_methods?.length > 0 && (
          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginTop: 8 }}>
            {listing.payment_methods.map((pm, i) => (
              <View key={i} style={styles.pmPill}><Text style={styles.pmText}>{pm}</Text></View>
            ))}
          </ScrollView>
        )}
      </Card>
    )
  }

  const OrderCard = ({ order }) => {
    const statusColor = { pending: COLORS.warning, escrow_locked: COLORS.info, completed: COLORS.success, disputed: COLORS.danger }[order.status] || COLORS.textMuted
    const isSeller = order.seller_id === user?.id
    return (
      <Card style={{ marginBottom: 10 }}>
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 }}>
          <Text style={{ color: COLORS.text, fontWeight: '700', fontSize: 14 }}>
            {isSeller ? 'Selling' : 'Buying'} {parseFloat(order.amount_crypto).toFixed(6)} {order.listing?.crypto || ''}
          </Text>
          <Badge label={order.status.replace('_', ' ')} type={order.status === 'completed' ? 'success' : order.status === 'escrow_locked' ? 'accent' : 'warning'} />
        </View>
        <InfoRow label="Amount"   value={`${order.fiat_currency} ${order.amount_fiat}`} />
        <InfoRow label="Role"     value={isSeller ? 'Seller' : 'Buyer'} />
        <InfoRow label="Expires"  value={order.expires_at ? new Date(order.expires_at).toLocaleTimeString() : '—'} last />
        {order.status === 'pending' && isSeller && (
          <PrimaryButton title="🔐 Lock Escrow" onPress={() => handleEscrow(order)} style={{ marginTop: 10 }} />
        )}
        {order.status === 'escrow_locked' && isSeller && (
          <PrimaryButton title="✅ Release Funds" onPress={() => handleRelease(order)} style={{ marginTop: 10 }} />
        )}
        {order.status === 'escrow_locked' && !isSeller && (
          <Alert type="info" style={{ marginTop: 10 }}>Funds are locked. Complete your payment and notify the seller.</Alert>
        )}
      </Card>
    )
  }

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>P2P Market</Text>
        <TouchableOpacity style={styles.postBtn} onPress={() => setShowCreate(true)}>
          <Text style={{ color: COLORS.accent, fontWeight: '700', fontSize: 13 }}>+ Post</Text>
        </TouchableOpacity>
      </View>

      {/* Tab bar */}
      <View style={styles.tabRow}>
        {[['buy','🟢 Buy'],['sell','🔴 Sell'],['myorders','📋 My Orders']].map(([k, l]) => (
          <TouchableOpacity key={k} style={[styles.tab, tab === k && styles.tabActive]} onPress={() => setTab(k)}>
            <Text style={[styles.tabText, tab === k && styles.tabTextActive]}>{l}</Text>
          </TouchableOpacity>
        ))}
      </View>

      {/* Filters */}
      {tab !== 'myorders' && (
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.filterScroll} contentContainerStyle={{ gap: 6, paddingHorizontal: SPACING.md }}>
          {CRYPTOS.map(c => (
            <TouchableOpacity key={c} style={[styles.filterPill, filterCrypto === c && styles.filterPillActive]} onPress={() => setFilterCrypto(c)}>
              <Text style={[styles.filterText, filterCrypto === c && styles.filterTextActive]}>{c}</Text>
            </TouchableOpacity>
          ))}
        </ScrollView>
      )}

      <ScrollView
        contentContainerStyle={styles.scroll}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => { setRefreshing(true); load() }} tintColor={COLORS.accent} />}
      >
        {loading ? (
          <View style={styles.centered}><Spinner /></View>
        ) : tab === 'myorders' ? (
          myOrders.length === 0 ? (
            <View style={styles.emptyWrap}>
              <Text style={{ fontSize: 48, marginBottom: 12 }}>📋</Text>
              <Text style={styles.emptyTitle}>No Orders Yet</Text>
              <Text style={styles.emptyDesc}>Your P2P trade orders will appear here.</Text>
            </View>
          ) : myOrders.map(o => <OrderCard key={o.id} order={o} />)
        ) : listings.length === 0 ? (
          <View style={styles.emptyWrap}>
            <Text style={{ fontSize: 48, marginBottom: 12 }}>🏪</Text>
            <Text style={styles.emptyTitle}>No Listings</Text>
            <Text style={styles.emptyDesc}>No active {tab} listings for {filterCrypto}. Be the first to post!</Text>
            <PrimaryButton title="+ Post Listing" onPress={() => setShowCreate(true)} style={{ marginTop: SPACING.md }} />
          </View>
        ) : listings.map(l => <ListingCard key={l.id} listing={l} />)
        }
      </ScrollView>

      {/* ── Create Listing Modal ── */}
      <Modal visible={showCreate} transparent animationType="slide">
        <View style={styles.modalOverlay}>
          <View style={styles.modalSheet}>
            <Text style={styles.modalTitle}>Post {lType.toUpperCase()} Listing</Text>
            <ScrollView keyboardShouldPersistTaps="handled">
              {/* Type */}
              <View style={styles.segRow}>
                {['buy','sell'].map(t => (
                  <TouchableOpacity key={t} style={[styles.segBtn, lType === t && styles.segBtnActive]} onPress={() => setLType(t)}>
                    <Text style={[styles.segText, lType === t && styles.segTextActive]}>{t.toUpperCase()}</Text>
                  </TouchableOpacity>
                ))}
              </View>
              {/* Crypto + Fiat */}
              <View style={{ flexDirection: 'row', gap: 8 }}>
                <View style={{ flex: 1 }}>
                  <Text style={styles.label}>Crypto</Text>
                  <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginBottom: SPACING.md }}>
                    {CRYPTOS.map(c => (
                      <TouchableOpacity key={c} style={[styles.filterPill, lCrypto === c && styles.filterPillActive, { marginRight: 6 }]} onPress={() => setLCrypto(c)}>
                        <Text style={[styles.filterText, lCrypto === c && styles.filterTextActive]}>{c}</Text>
                      </TouchableOpacity>
                    ))}
                  </ScrollView>
                </View>
              </View>
              <Text style={styles.label}>Fiat Currency</Text>
              <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginBottom: SPACING.md }}>
                {FIATS.map(f => (
                  <TouchableOpacity key={f} style={[styles.filterPill, lFiat === f && styles.filterPillActive, { marginRight: 6 }]} onPress={() => setLFiat(f)}>
                    <Text style={[styles.filterText, lFiat === f && styles.filterTextActive]}>{f}</Text>
                  </TouchableOpacity>
                ))}
              </ScrollView>
              <Input label={`Amount (${lCrypto})`} value={lAmount} onChangeText={setLAmount} keyboardType="decimal-pad" placeholder="e.g. 100" />
              <Input label={`Price per ${lCrypto} (${lFiat})`} value={lPrice} onChangeText={setLPrice} keyboardType="decimal-pad" placeholder="e.g. 1.02" />
              <View style={{ flexDirection: 'row', gap: 8 }}>
                <View style={{ flex: 1 }}><Input label={`Min Order (${lFiat})`} value={lMin} onChangeText={setLMin} keyboardType="decimal-pad" placeholder="10" /></View>
                <View style={{ flex: 1 }}><Input label={`Max Order (${lFiat})`} value={lMax} onChangeText={setLMax} keyboardType="decimal-pad" placeholder="500" /></View>
              </View>
              {/* Country */}
              <Text style={styles.label}>Your Country</Text>
              <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginBottom: SPACING.md }}>
                {COUNTRIES.map(c => (
                  <TouchableOpacity key={c} style={[styles.filterPill, lCountry === c && styles.filterPillActive, { marginRight: 6 }]} onPress={() => setLCountry(c)}>
                    <Text style={[styles.filterText, lCountry === c && styles.filterTextActive]}>{FLAG[c]} {c}</Text>
                  </TouchableOpacity>
                ))}
              </ScrollView>
              {/* Payment methods */}
              <Text style={styles.label}>Payment Methods</Text>
              <View style={styles.pmGrid}>
                {PMETHODS.map(pm => (
                  <TouchableOpacity key={pm} style={[styles.pmBtn, lPMs.includes(pm) && styles.pmBtnActive]}
                    onPress={() => setLPMs(p => p.includes(pm) ? p.filter(x => x !== pm) : [...p, pm])}>
                    <Text style={[styles.pmBtnText, lPMs.includes(pm) && { color: COLORS.accent }]}>{pm}</Text>
                  </TouchableOpacity>
                ))}
              </View>
              <View style={{ flexDirection: 'row', gap: 8, marginTop: SPACING.md }}>
                <SecondaryButton title="Cancel" onPress={() => setShowCreate(false)} style={{ flex: 1 }} />
                <PrimaryButton title="Post Listing" onPress={handleCreate} loading={creating} style={{ flex: 1 }} />
              </View>
            </ScrollView>
          </View>
        </View>
      </Modal>

      {/* ── Order Modal ── */}
      <Modal visible={orderModal} transparent animationType="slide">
        <View style={styles.modalOverlay}>
          <View style={[styles.modalSheet, { maxHeight: 420 }]}>
            <Text style={styles.modalTitle}>
              {orderListing?.type === 'buy' ? 'Sell to this buyer' : 'Buy from this seller'}
            </Text>
            {orderListing && (
              <>
                <InfoRow label="Price"   value={`${orderListing.fiat_currency} ${orderListing.price_per_unit} / ${orderListing.crypto}`} />
                <InfoRow label="Limits"  value={`${orderListing.fiat_currency} ${orderListing.min_order} – ${orderListing.max_order}`} />
                <InfoRow label="Methods" value={(orderListing.payment_methods || []).join(', ')} last />
                <Input
                  label={`Amount (${orderListing.fiat_currency})`}
                  value={orderAmt} onChangeText={setOrderAmt}
                  keyboardType="decimal-pad" placeholder={`Min: ${orderListing.min_order}`}
                />
                {orderAmt && parseFloat(orderAmt) > 0 && (
                  <Text style={{ color: COLORS.textMuted, fontSize: 13, marginTop: -8, marginBottom: 12 }}>
                    ≈ {(parseFloat(orderAmt) / parseFloat(orderListing.price_per_unit)).toFixed(6)} {orderListing.crypto}
                  </Text>
                )}
                <Alert type="warning" style={{ marginBottom: SPACING.md }}>
                  Seller must lock funds in escrow before you send payment. Only release escrow once payment is received.
                </Alert>
              </>
            )}
            <View style={{ flexDirection: 'row', gap: 8 }}>
              <SecondaryButton title="Cancel" onPress={() => { setOrderModal(false); setOrderAmt('') }} style={{ flex: 1 }} />
              <PrimaryButton title="Place Order" onPress={handleOrder} loading={placingOrder} style={{ flex: 1 }} />
            </View>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  )
}

const styles = StyleSheet.create({
  safe:   { flex: 1, backgroundColor: COLORS.bg },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingHorizontal: SPACING.md, paddingVertical: 12 },
  headerTitle: { fontSize: 22, fontWeight: '800', color: COLORS.text },
  postBtn: { backgroundColor: COLORS.accentDim, borderRadius: RADIUS.md, paddingHorizontal: 14, paddingVertical: 7, borderWidth: 1, borderColor: 'rgba(124,111,247,0.3)' },
  tabRow: { flexDirection: 'row', marginHorizontal: SPACING.md, backgroundColor: COLORS.surface2, borderRadius: RADIUS.md, padding: 4, marginBottom: 8 },
  tab: { flex: 1, paddingVertical: 9, borderRadius: RADIUS.sm - 2, alignItems: 'center' },
  tabActive: { backgroundColor: COLORS.surface },
  tabText: { fontSize: 12, fontWeight: '600', color: COLORS.textMuted },
  tabTextActive: { color: COLORS.text },
  filterScroll: { marginBottom: 8 },
  filterPill: { paddingHorizontal: 12, paddingVertical: 6, borderRadius: 100, backgroundColor: COLORS.surface2, borderWidth: 1, borderColor: COLORS.border },
  filterPillActive: { backgroundColor: COLORS.accentDim, borderColor: 'rgba(124,111,247,0.4)' },
  filterText: { fontSize: 12, fontWeight: '600', color: COLORS.textMuted },
  filterTextActive: { color: COLORS.accent },
  scroll: { padding: SPACING.md, paddingBottom: 40 },
  centered: { paddingVertical: 60, alignItems: 'center' },
  emptyWrap: { paddingVertical: 60, alignItems: 'center' },
  emptyTitle: { fontSize: 18, fontWeight: '700', color: COLORS.text, marginBottom: 8 },
  emptyDesc:  { color: COLORS.textMuted, textAlign: 'center', lineHeight: 20, marginBottom: SPACING.md },
  listingCard: { marginBottom: 10 },
  listingHeader: { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 10 },
  typeBadge: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: 100 },
  listingCrypto: { flex: 1, fontSize: 16, fontWeight: '800', color: COLORS.text },
  listingFlag: { fontSize: 22 },
  listingBody: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  listingPrice: { fontSize: 18, fontWeight: '800', color: COLORS.text, marginBottom: 4 },
  listingMeta:  { fontSize: 11, color: COLORS.textMuted, marginBottom: 2 },
  tradeBtn: { paddingHorizontal: 16, paddingVertical: 10, borderRadius: RADIUS.md, borderWidth: 1, borderColor: COLORS.border },
  pmPill: { backgroundColor: COLORS.surface3, borderRadius: 100, paddingHorizontal: 10, paddingVertical: 4, marginRight: 6, borderWidth: 1, borderColor: COLORS.border },
  pmText: { fontSize: 11, color: COLORS.textMuted, fontWeight: '600' },
  label: { fontSize: 11, fontWeight: '700', letterSpacing: 1, textTransform: 'uppercase', color: COLORS.textMuted, marginBottom: 6 },
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.8)', justifyContent: 'flex-end' },
  modalSheet:   { backgroundColor: COLORS.surface, borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: SPACING.lg, maxHeight: '90%' },
  modalTitle:   { fontSize: 20, fontWeight: '800', color: COLORS.text, marginBottom: SPACING.md },
  segRow: { flexDirection: 'row', backgroundColor: COLORS.surface2, borderRadius: RADIUS.md, padding: 4, marginBottom: SPACING.md },
  segBtn: { flex: 1, paddingVertical: 10, borderRadius: RADIUS.sm - 2, alignItems: 'center' },
  segBtnActive: { backgroundColor: COLORS.surface },
  segText: { fontWeight: '700', color: COLORS.textMuted },
  segTextActive: { color: COLORS.text },
  pmGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: SPACING.md },
  pmBtn: { paddingHorizontal: 12, paddingVertical: 7, borderRadius: 100, borderWidth: 1, borderColor: COLORS.border, backgroundColor: COLORS.surface2 },
  pmBtnActive: { borderColor: COLORS.accent, backgroundColor: COLORS.accentDim },
  pmBtnText: { fontSize: 12, fontWeight: '600', color: COLORS.textMuted },
})
