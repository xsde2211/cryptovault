// src/screens/kyc/KYCScreen.js
import React, { useState, useEffect } from 'react'
import {
  View, Text, ScrollView, TouchableOpacity, StyleSheet,
  Image, Platform, Alert as RNAlert,
} from 'react-native'
import { SafeAreaView } from 'react-native-safe-area-context'
import * as ImagePicker from 'expo-image-picker'
import * as DocumentPicker from 'expo-document-picker'
import { submitKYC, getMyKYC, generateUniqueCode } from '../../services/supabase/cardService'
import { supabase } from '../../services/supabase/client'
import { useApp } from '../../context/AppContext'
import { COLORS, SPACING, RADIUS } from '../../utils/theme'
import { Card, PrimaryButton, SecondaryButton, Input, Alert, Badge, Spinner } from '../../components/UI'
import Toast from 'react-native-toast-message'

const STEPS = ['Identity', 'Selfie', 'Document', 'Review']
const DOC_TYPES = ['Passport', 'Driving Licence', 'Identity Card', 'Other Proof']

export default function KYCScreen({ navigation }) {
  const { user } = useApp()
  const [step,        setStep]        = useState(0)
  const [existingKYC, setExistingKYC] = useState(null)
  const [loading,     setLoading]     = useState(true)
  const [submitting,  setSubmitting]  = useState(false)

  // Step 0 — Identity
  const [fullName, setFullName] = useState('')
  const [email,    setEmail]    = useState('')
  const [phone,    setPhone]    = useState('')
  const [address,  setAddress]  = useState('')

  // Step 1 — Selfie
  const [selfieMode,   setSelfieMode]   = useState('code')   // 'code' | 'video'
  const [uniqueCode,   setUniqueCode]   = useState('')
  const [selfieUri,    setSelfieUri]    = useState(null)
  const [selfieUploading, setSelfieUploading] = useState(false)
  const [selfieUrl,    setSelfieUrl]    = useState(null)

  // Step 2 — Document
  const [docType,      setDocType]      = useState('Passport')
  const [docUri,       setDocUri]       = useState(null)
  const [docUploading, setDocUploading] = useState(false)
  const [docUrl,       setDocUrl]       = useState(null)

  const [error, setError] = useState('')

  useEffect(() => {
    getMyKYC().then(kyc => { setExistingKYC(kyc); setLoading(false) }).catch(() => setLoading(false))
    setUniqueCode(generateUniqueCode())
  }, [])

  // ── File upload to Supabase Storage ──────────────────────────
  const uploadFile = async (uri, bucket, folder) => {
    const ext      = uri.split('.').pop() || 'jpg'
    const fileName = `${folder}/${user.id}_${Date.now()}.${ext}`
    const response = await fetch(uri)
    const blob     = await response.blob()
    const { data, error } = await supabase.storage.from(bucket).upload(fileName, blob, { contentType: `image/${ext}` })
    if (error) throw error
    const { data: urlData } = supabase.storage.from(bucket).getPublicUrl(fileName)
    return urlData.publicUrl
  }

  const pickSelfie = async () => {
    const perm = await ImagePicker.requestCameraPermissionsAsync()
    if (!perm.granted) { Toast.show({ type: 'error', text1: 'Camera permission required' }); return }
    const result = await ImagePicker.launchCameraAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      quality: 0.8,
      allowsEditing: false,
    })
    if (!result.canceled && result.assets?.[0]) {
      setSelfieUri(result.assets[0].uri)
      setSelfieUploading(true)
      try {
        const url = await uploadFile(result.assets[0].uri, 'kyc-documents', 'selfies')
        setSelfieUrl(url)
        Toast.show({ type: 'success', text1: 'Selfie uploaded ✅' })
      } catch (err) { Toast.show({ type: 'error', text1: 'Upload failed: ' + err.message }) }
      setSelfieUploading(false)
    }
  }

  const pickDocument = async () => {
    try {
      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        quality: 0.9,
      })
      if (!result.canceled && result.assets?.[0]) {
        setDocUri(result.assets[0].uri)
        setDocUploading(true)
        const url = await uploadFile(result.assets[0].uri, 'kyc-documents', 'docs')
        setDocUrl(url)
        Toast.show({ type: 'success', text1: 'Document uploaded ✅' })
        setDocUploading(false)
      }
    } catch (err) { Toast.show({ type: 'error', text1: err.message }); setDocUploading(false) }
  }

  const pickDocumentFile = async () => {
    try {
      const result = await DocumentPicker.getDocumentAsync({ type: ['image/*', 'application/pdf'] })
      if (!result.canceled && result.assets?.[0]) {
        setDocUri(result.assets[0].uri)
        setDocUploading(true)
        const url = await uploadFile(result.assets[0].uri, 'kyc-documents', 'docs')
        setDocUrl(url)
        Toast.show({ type: 'success', text1: 'Document uploaded ✅' })
        setDocUploading(false)
      }
    } catch (err) { Toast.show({ type: 'error', text1: err.message }); setDocUploading(false) }
  }

  const validateStep = () => {
    setError('')
    if (step === 0) {
      if (!fullName.trim()) { setError('Enter your full name'); return false }
      if (!email.trim() || !email.includes('@')) { setError('Enter a valid email'); return false }
      if (!phone.trim() || phone.length < 7) { setError('Enter a valid phone number'); return false }
      if (!address.trim()) { setError('Enter your full address'); return false }
    }
    if (step === 1 && !selfieUri) { setError('Please take a selfie'); return false }
    if (step === 2 && !docUri)    { setError('Please upload a document'); return false }
    return true
  }

  const handleNext = () => {
    if (!validateStep()) return
    if (step < STEPS.length - 1) setStep(s => s + 1)
  }

  const handleSubmit = async () => {
    setSubmitting(true)
    try {
      await submitKYC({
        full_name:   fullName,
        email,
        phone,
        address,
        selfie_url:  selfieUrl,
        unique_code: selfieMode === 'code' ? uniqueCode : null,
        doc_type:    docType,
        doc_url:     docUrl,
        kyc_type:    'personal',
      })
      Toast.show({ type: 'success', text1: 'KYC submitted! Under review 🎉' })
      navigation.goBack()
    } catch (err) { Toast.show({ type: 'error', text1: err.message }) }
    setSubmitting(false)
  }

  if (loading) return <View style={styles.centered}><Spinner size="large" /></View>

  if (existingKYC) return (
    <SafeAreaView style={styles.safe} edges={['bottom']}>
      <ScrollView contentContainerStyle={styles.scroll}>
        <View style={{ alignItems: 'center', paddingVertical: 40 }}>
          <Text style={{ fontSize: 60, marginBottom: 16 }}>
            {existingKYC.status === 'approved' ? '✅' : existingKYC.status === 'rejected' ? '❌' : '⏳'}
          </Text>
          <Text style={styles.cardTitle}>KYC {existingKYC.status === 'approved' ? 'Approved' : existingKYC.status === 'rejected' ? 'Rejected' : 'Under Review'}</Text>
          <Badge label={existingKYC.status} type={existingKYC.status === 'approved' ? 'success' : existingKYC.status === 'rejected' ? 'danger' : 'warning'} style={{ marginBottom: SPACING.md }} />
          <Text style={{ color: COLORS.textMuted, textAlign: 'center', lineHeight: 20, marginBottom: SPACING.lg }}>
            {existingKYC.status === 'pending' ? 'Your KYC is being reviewed. This typically takes 1–2 business days.'
              : existingKYC.status === 'approved' ? 'Your identity has been verified. You can now apply for virtual cards.'
              : `Your KYC was rejected. Reason: ${existingKYC.notes || 'Document unclear'}`}
          </Text>
          <Card style={{ width: '100%' }}>
            {[
              { label: 'Name',     value: existingKYC.full_name },
              { label: 'Email',    value: existingKYC.email },
              { label: 'Phone',    value: existingKYC.phone },
              { label: 'Doc Type', value: existingKYC.doc_type },
              { label: 'Submitted',value: new Date(existingKYC.created_at).toLocaleDateString() },
            ].map((r, i, arr) => (
              <View key={r.label} style={[styles.reviewRow, i < arr.length - 1 && { borderBottomWidth: 1, borderBottomColor: COLORS.border }]}>
                <Text style={styles.reviewLabel}>{r.label}</Text>
                <Text style={styles.reviewValue}>{r.value}</Text>
              </View>
            ))}
          </Card>
          {existingKYC.status === 'rejected' && (
            <PrimaryButton title="Resubmit KYC" onPress={() => setExistingKYC(null)} style={{ marginTop: SPACING.lg, width: '100%' }} />
          )}
        </View>
      </ScrollView>
    </SafeAreaView>
  )

  return (
    <SafeAreaView style={styles.safe} edges={['bottom']}>
      <ScrollView contentContainerStyle={styles.scroll} keyboardShouldPersistTaps="handled">

        {/* Progress */}
        <View style={styles.progressRow}>
          {STEPS.map((s, i) => (
            <View key={s} style={{ alignItems: 'center', flex: 1 }}>
              <View style={[styles.stepDot, i < step && styles.stepDone, i === step && styles.stepActive]}>
                <Text style={{ fontSize: 11, fontWeight: '700', color: i <= step ? '#fff' : COLORS.textMuted }}>{i < step ? '✓' : i + 1}</Text>
              </View>
              <Text style={{ fontSize: 9, marginTop: 4, color: i === step ? COLORS.accent : COLORS.textDim }}>{s}</Text>
            </View>
          ))}
        </View>
        <View style={styles.progressBar}>
          <View style={[styles.progressFill, { width: `${(step / (STEPS.length - 1)) * 100}%` }]} />
        </View>

        {error ? <Alert type="danger">{error}</Alert> : null}

        {/* ── STEP 0: Identity ── */}
        {step === 0 && (
          <Card>
            <Text style={styles.cardTitle}>Personal Information</Text>
            <Text style={styles.cardDesc}>We need this to verify your identity and comply with financial regulations.</Text>
            <Input label="Full Legal Name" value={fullName} onChangeText={setFullName} placeholder="As on official ID" autoCapitalize="words" />
            <Input label="Email Address" value={email} onChangeText={setEmail} placeholder="your@email.com" keyboardType="email-address" autoCapitalize="none" />
            <Input label="Phone Number" value={phone} onChangeText={setPhone} placeholder="+1 555 000 0000" keyboardType="phone-pad" />
            <Input label="Full Address" value={address} onChangeText={setAddress} placeholder="Street, City, Country, Postal Code" multiline numberOfLines={3} />
            <PrimaryButton title="Continue →" onPress={handleNext} />
          </Card>
        )}

        {/* ── STEP 1: Selfie ── */}
        {step === 1 && (
          <Card>
            <Text style={styles.cardTitle}>Identity Selfie</Text>
            <Text style={styles.cardDesc}>We need to verify it's really you. Choose a method:</Text>

            {/* Mode toggle */}
            <View style={styles.tabRow}>
              <TouchableOpacity style={[styles.tab, selfieMode === 'code' && styles.tabActive]} onPress={() => setSelfieMode('code')}>
                <Text style={[styles.tabText, selfieMode === 'code' && styles.tabTextActive]}>🤳 Code Selfie</Text>
              </TouchableOpacity>
              <TouchableOpacity style={[styles.tab, selfieMode === 'video' && styles.tabActive]} onPress={() => setSelfieMode('video')}>
                <Text style={[styles.tabText, selfieMode === 'video' && styles.tabTextActive]}>👁 Eye Blink Video</Text>
              </TouchableOpacity>
            </View>

            {selfieMode === 'code' ? (
              <>
                <View style={styles.codeBox}>
                  <Text style={styles.codeLabel}>Your Unique Code</Text>
                  <Text style={styles.codeText}>{uniqueCode}</Text>
                  <Text style={styles.codeHint}>Write this code on a white paper and hold it in your selfie</Text>
                </View>
                <Alert type="info">Hold the paper clearly visible · Face must be fully visible · Good lighting</Alert>
              </>
            ) : (
              <Alert type="info">Record a short video (3–5 sec) looking at the camera and blinking both eyes slowly. Face must fill the frame.</Alert>
            )}

            {selfieUri ? (
              <View style={styles.previewWrap}>
                <Image source={{ uri: selfieUri }} style={styles.previewImg} />
                {selfieUploading && (
                  <View style={styles.uploadingOverlay}>
                    <Spinner color="#fff" />
                    <Text style={{ color: '#fff', marginTop: 8 }}>Uploading…</Text>
                  </View>
                )}
                {selfieUrl && <View style={styles.uploadedBadge}><Text style={{ color: COLORS.success, fontWeight: '700' }}>✓ Uploaded</Text></View>}
                <TouchableOpacity style={styles.retakeBtn} onPress={() => { setSelfieUri(null); setSelfieUrl(null) }}>
                  <Text style={{ color: COLORS.danger, fontWeight: '600' }}>Retake</Text>
                </TouchableOpacity>
              </View>
            ) : (
              <TouchableOpacity style={styles.cameraBtn} onPress={pickSelfie}>
                <Text style={{ fontSize: 40, marginBottom: 8 }}>📷</Text>
                <Text style={{ color: COLORS.text, fontWeight: '700' }}>Open Camera</Text>
                <Text style={{ color: COLORS.textMuted, fontSize: 12, marginTop: 4 }}>Take selfie {selfieMode === 'code' ? 'with code paper' : 'with eye blink'}</Text>
              </TouchableOpacity>
            )}

            <View style={{ flexDirection: 'row', gap: 8, marginTop: 8 }}>
              <SecondaryButton title="← Back" onPress={() => setStep(0)} style={{ flex: 1 }} />
              <PrimaryButton title="Continue →" onPress={handleNext} style={{ flex: 1 }} />
            </View>
          </Card>
        )}

        {/* ── STEP 2: Document ── */}
        {step === 2 && (
          <Card>
            <Text style={styles.cardTitle}>Upload Document</Text>
            <Text style={styles.cardDesc}>Upload a clear photo or scan of your government-issued ID.</Text>

            <Text style={styles.label}>Document Type</Text>
            <View style={styles.docTypeGrid}>
              {DOC_TYPES.map(dt => (
                <TouchableOpacity key={dt} style={[styles.docTypeBtn, docType === dt && styles.docTypeBtnActive]} onPress={() => setDocType(dt)}>
                  <Text style={{ fontSize: 20, marginBottom: 4 }}>
                    {dt === 'Passport' ? '🛂' : dt === 'Driving Licence' ? '🚗' : dt === 'Identity Card' ? '🪪' : '📄'}
                  </Text>
                  <Text style={[styles.docTypeLabel, docType === dt && { color: COLORS.accent }]}>{dt}</Text>
                </TouchableOpacity>
              ))}
            </View>

            {docUri ? (
              <View style={styles.previewWrap}>
                <Image source={{ uri: docUri }} style={styles.previewImg} />
                {docUploading && (
                  <View style={styles.uploadingOverlay}>
                    <Spinner color="#fff" />
                    <Text style={{ color: '#fff', marginTop: 8 }}>Uploading…</Text>
                  </View>
                )}
                {docUrl && <View style={styles.uploadedBadge}><Text style={{ color: COLORS.success, fontWeight: '700' }}>✓ Uploaded</Text></View>}
                <TouchableOpacity style={styles.retakeBtn} onPress={() => { setDocUri(null); setDocUrl(null) }}>
                  <Text style={{ color: COLORS.danger, fontWeight: '600' }}>Remove</Text>
                </TouchableOpacity>
              </View>
            ) : (
              <View style={{ flexDirection: 'row', gap: 10, marginTop: 8 }}>
                <TouchableOpacity style={[styles.uploadBtn, { flex: 1 }]} onPress={pickDocument}>
                  <Text style={{ fontSize: 28, marginBottom: 6 }}>📷</Text>
                  <Text style={{ color: COLORS.text, fontWeight: '600', fontSize: 13 }}>Take Photo</Text>
                </TouchableOpacity>
                <TouchableOpacity style={[styles.uploadBtn, { flex: 1 }]} onPress={pickDocumentFile}>
                  <Text style={{ fontSize: 28, marginBottom: 6 }}>📁</Text>
                  <Text style={{ color: COLORS.text, fontWeight: '600', fontSize: 13 }}>Upload File</Text>
                </TouchableOpacity>
              </View>
            )}

            <Alert type="warning" style={{ marginTop: 12 }}>
              Ensure all corners are visible. File must be clear and legible. Max 10MB.
            </Alert>

            <View style={{ flexDirection: 'row', gap: 8, marginTop: 8 }}>
              <SecondaryButton title="← Back" onPress={() => setStep(1)} style={{ flex: 1 }} />
              <PrimaryButton title="Continue →" onPress={handleNext} style={{ flex: 1 }} />
            </View>
          </Card>
        )}

        {/* ── STEP 3: Review & Submit ── */}
        {step === 3 && (
          <Card>
            <Text style={styles.cardTitle}>Review & Submit</Text>
            <Text style={styles.cardDesc}>Please confirm your details before submitting.</Text>

            {[
              { label: 'Full Name', value: fullName },
              { label: 'Email',     value: email },
              { label: 'Phone',     value: phone },
              { label: 'Address',   value: address },
              { label: 'Doc Type',  value: docType },
              { label: 'Selfie',    value: selfieUri ? '✓ Uploaded' : '✗ Missing' },
              { label: 'Document',  value: docUri    ? '✓ Uploaded' : '✗ Missing' },
            ].map((r, i, arr) => (
              <View key={r.label} style={[styles.reviewRow, i < arr.length - 1 && { borderBottomWidth: 1, borderBottomColor: COLORS.border }]}>
                <Text style={styles.reviewLabel}>{r.label}</Text>
                <Text style={[styles.reviewValue, r.value.startsWith('✓') && { color: COLORS.success }, r.value.startsWith('✗') && { color: COLORS.danger }]}>
                  {r.value}
                </Text>
              </View>
            ))}

            <Alert type="info" style={{ marginTop: SPACING.md }}>
              By submitting, you confirm all information is accurate. False information may result in account suspension.
            </Alert>

            <View style={{ flexDirection: 'row', gap: 8, marginTop: SPACING.md }}>
              <SecondaryButton title="← Back" onPress={() => setStep(2)} style={{ flex: 1 }} />
              <PrimaryButton title="Submit KYC 🚀" onPress={handleSubmit} loading={submitting} style={{ flex: 1.3 }} />
            </View>
          </Card>
        )}
      </ScrollView>
    </SafeAreaView>
  )
}

const styles = StyleSheet.create({
  safe:    { flex: 1, backgroundColor: COLORS.bg },
  scroll:  { padding: SPACING.md, paddingBottom: 40 },
  centered:{ flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: COLORS.bg },
  progressRow: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 10 },
  stepDot: { width: 28, height: 28, borderRadius: 14, justifyContent: 'center', alignItems: 'center', backgroundColor: COLORS.surface2, borderWidth: 1.5, borderColor: COLORS.border },
  stepActive: { backgroundColor: 'rgba(124,111,247,0.2)', borderColor: COLORS.accent },
  stepDone:   { backgroundColor: COLORS.accent, borderColor: COLORS.accent },
  progressBar:  { height: 3, backgroundColor: COLORS.border, borderRadius: 2, marginBottom: SPACING.md },
  progressFill: { height: 3, backgroundColor: COLORS.accent, borderRadius: 2 },
  cardTitle: { fontSize: 20, fontWeight: '800', color: COLORS.text, marginBottom: 6 },
  cardDesc:  { fontSize: 13, color: COLORS.textMuted, lineHeight: 19, marginBottom: SPACING.md },
  label:     { fontSize: 11, fontWeight: '700', letterSpacing: 1, textTransform: 'uppercase', color: COLORS.textMuted, marginBottom: 8 },
  tabRow: { flexDirection: 'row', backgroundColor: COLORS.surface2, borderRadius: RADIUS.md, padding: 4, marginBottom: SPACING.md },
  tab: { flex: 1, paddingVertical: 9, borderRadius: RADIUS.sm - 2, alignItems: 'center' },
  tabActive: { backgroundColor: COLORS.surface },
  tabText:       { fontSize: 13, fontWeight: '600', color: COLORS.textMuted },
  tabTextActive: { color: COLORS.text },
  codeBox: { backgroundColor: COLORS.surface2, borderRadius: RADIUS.md, padding: SPACING.md, alignItems: 'center', marginBottom: SPACING.md, borderWidth: 1, borderColor: 'rgba(124,111,247,0.25)' },
  codeLabel: { fontSize: 11, fontWeight: '700', letterSpacing: 1, textTransform: 'uppercase', color: COLORS.textMuted, marginBottom: 10 },
  codeText:  { fontSize: 26, fontWeight: '800', color: COLORS.accent, letterSpacing: 4, fontFamily: Platform.OS === 'ios' ? 'Courier New' : 'monospace' },
  codeHint:  { color: COLORS.textDim, fontSize: 11, marginTop: 8, textAlign: 'center' },
  cameraBtn: { backgroundColor: COLORS.surface2, borderRadius: RADIUS.lg, padding: SPACING.xl, alignItems: 'center', borderWidth: 1.5, borderColor: COLORS.border, borderStyle: 'dashed', marginTop: SPACING.md },
  previewWrap: { position: 'relative', marginTop: SPACING.md, marginBottom: SPACING.md, borderRadius: RADIUS.md, overflow: 'hidden' },
  previewImg:  { width: '100%', height: 200, borderRadius: RADIUS.md },
  uploadingOverlay: { position: 'absolute', inset: 0, backgroundColor: 'rgba(0,0,0,0.6)', justifyContent: 'center', alignItems: 'center', borderRadius: RADIUS.md },
  uploadedBadge: { position: 'absolute', top: 8, right: 8, backgroundColor: 'rgba(16,185,129,0.2)', borderRadius: 100, paddingHorizontal: 10, paddingVertical: 4, borderWidth: 1, borderColor: COLORS.success },
  retakeBtn: { marginTop: 8, alignItems: 'center', paddingVertical: 8 },
  docTypeGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: SPACING.md },
  docTypeBtn: { width: '47%', padding: 14, borderRadius: RADIUS.md, backgroundColor: COLORS.surface2, borderWidth: 1, borderColor: COLORS.border, alignItems: 'center' },
  docTypeBtnActive: { borderColor: COLORS.accent, backgroundColor: COLORS.accentDim },
  docTypeLabel: { fontSize: 12, fontWeight: '600', color: COLORS.textMuted, textAlign: 'center' },
  uploadBtn: { backgroundColor: COLORS.surface2, borderRadius: RADIUS.lg, padding: SPACING.lg, alignItems: 'center', borderWidth: 1.5, borderColor: COLORS.border, borderStyle: 'dashed' },
  reviewRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingVertical: 10 },
  reviewLabel: { color: COLORS.textMuted, fontSize: 13, flex: 1 },
  reviewValue: { color: COLORS.text, fontWeight: '600', fontSize: 13, maxWidth: 200, textAlign: 'right' },
})
