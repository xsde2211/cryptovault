// src/screens/main/DashboardScreen.js
import React, { useState, useEffect, useCallback } from 'react'
import {
  View, Text, ScrollView, TouchableOpacity,
  StyleSheet, RefreshControl, Platform,
} from 'react-native'
import { SafeAreaView } from 'react-native-safe-area-context'
import { LinearGradient } from 'expo-linear-gradient'
import { useNavigation } from '@react-navigation/native'
import { getNativeBalance, formatBalance, shortenAddress } from '../../services/blockchain/walletService'
import { fetchPrices, formatPrice } from '../../services/priceService'
import { getTokens } from '../../services/supabase/walletDbService'
import { getUserCards } from '../../services/supabase/cardService'
import { getNetwork } from '../../utils/networks'
import { useApp } from '../../context/AppContext'
import { COLORS, SPACING, RADIUS, SHADOWS } from '../../utils/theme'
import { Card, Spinner } from '../../components/UI'

export default function DashboardScreen() {
  const navigation = useNavigation()
  const { activeWallet, activeNetwork, wallets, prefs, loadWallets } = useApp()
  const network = getNetwork(activeNetwork)

  const [balance,    setBalance]    = useState(null)
  const [tokens,     setTokens]     = useState([])
  const [price,      setPrice]      = useState(null)
  const [cardCount,  setCardCount]  = useState(0)
  const [loading,    setLoading]    = useState(true)
  const [refreshing, setRefreshing] = useState(false)

  const load = useCallback(async () => {
    if (!activeWallet) { setLoading(false); return }
    try {
      const [bal, tks, cards] = await Promise.all([
        getNativeBalance(activeWallet.address, activeNetwork),
        getTokens(activeWallet.address, activeNetwork),
        getUserCards(),
      ])
      setBalance(bal)
      setTokens(tks)
      setCardCount(cards.length)
      if (network.coingeckoId) {
        const p = await fetchPrices([network.coingeckoId])
        setPrice(p[network.coingeckoId]?.usd || null)
      }
    } catch {} finally { setLoading(false); setRefreshing(false) }
  }, [activeWallet, activeNetwork])

  useEffect(() => { load() }, [load])

  const nativeUSD = balance && price ? (parseFloat(balance) * price) : null
  const masked    = '••••••'

  // Quick actions
  const ACTIONS = [
    { icon: '↑', label: 'Send',      color: '#f43f5e', screen: 'Send' },
    { icon: '↓', label: 'Receive',   color: '#10b981', screen: 'Receive' },
    { icon: '⇄', label: 'Swap',      color: '#7c6ff7', screen: 'Swap' },
    { icon: '💳', label: 'Cards',     color: '#4facfe', screen: 'Cards' },
    { icon: '◈', label: 'TRON',      color: '#EF0027', screen: 'TRON' },
    { icon: '🏪', label: 'P2P',       color: '#f59e0b', screen: 'P2P' },
    { icon: '📋', label: 'History',   color: '#06b6d4', screen: 'Transactions' },
    { icon: '⭐', label: 'Markets',   color: '#8247E5', screen: 'Watchlist' },
  ]

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <ScrollView
        contentContainerStyle={styles.scroll}
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={() => { setRefreshing(true); loadWallets(); load() }}
            tintColor={COLORS.accent}
          />
        }
      >
        {/* ── Header ── */}
        <View style={styles.header}>
          <View>
            <Text style={styles.greeting}>CryptoVault</Text>
            <Text style={styles.walletAddr} numberOfLines={1}>
              {activeWallet ? shortenAddress(activeWallet.address) : 'No wallet'}
            </Text>
          </View>
          <TouchableOpacity
            style={[styles.netPill, { backgroundColor: `${network.color}18` }]}
            onPress={() => navigation.navigate('More')}
          >
            <View style={[styles.netDot, { backgroundColor: network.color }]} />
            <Text style={[styles.netName, { color: network.color }]}>{network.shortName}</Text>
            {network.isTestnet && <Text style={{ fontSize: 9, color: COLORS.warning, fontWeight: '700' }}> TEST</Text>}
          </TouchableOpacity>
        </View>

        {/* ── Balance Card ── */}
        {loading ? (
          <View style={[styles.balCard, { justifyContent: 'center', alignItems: 'center' }]}>
            <Spinner color="#fff" />
          </View>
        ) : (
          <LinearGradient
            colors={['#1a1040', '#0d0e14']}
            style={styles.balCard}
          >
            {/* Glow */}
            <View style={[styles.balGlow, { backgroundColor: `${network.color}20` }]} />

            <Text style={styles.balLabel}>Total Balance</Text>
            <Text style={styles.balValue}>
              {prefs.hideBalances ? masked : (balance !== null ? formatBalance(balance, 6) : '—')}
            </Text>
            <Text style={styles.balSymbol}>{network.currency.symbol}</Text>
            {nativeUSD !== null && !prefs.hideBalances && (
              <Text style={styles.balUSD}>≈ ${nativeUSD.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</Text>
            )}
            {price && (
              <Text style={styles.priceTag}>
                {network.currency.symbol} = {formatPrice(price)}
              </Text>
            )}

            {/* Wallet pills row */}
            {wallets.length > 1 && (
              <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginTop: 16 }}>
                {wallets.map(w => (
                  <View key={w.id} style={styles.walletPill}>
                    <Text style={{ color: 'rgba(255,255,255,0.6)', fontSize: 10, fontFamily: 'monospace' }}>
                      {shortenAddress(w.address)}
                    </Text>
                  </View>
                ))}
              </ScrollView>
            )}

            {!activeWallet && (
              <View style={{ flexDirection: 'row', gap: 8, marginTop: 16 }}>
                <TouchableOpacity style={styles.createWalletBtn} onPress={() => navigation.navigate('CreateWallet')}>
                  <Text style={{ color: '#fff', fontWeight: '700', fontSize: 13 }}>+ Create Wallet</Text>
                </TouchableOpacity>
                <TouchableOpacity style={[styles.createWalletBtn, { backgroundColor: 'rgba(255,255,255,0.08)' }]} onPress={() => navigation.navigate('ImportWallet')}>
                  <Text style={{ color: '#fff', fontWeight: '700', fontSize: 13 }}>Import</Text>
                </TouchableOpacity>
              </View>
            )}
          </LinearGradient>
        )}

        {/* ── Quick Actions Grid ── */}
        <View style={styles.actionsGrid}>
          {ACTIONS.map(a => (
            <TouchableOpacity
              key={a.screen}
              style={styles.actionBtn}
              onPress={() => navigation.navigate(a.screen)}
              activeOpacity={0.75}
            >
              <View style={[styles.actionIcon, { backgroundColor: `${a.color}18` }]}>
                <Text style={{ fontSize: 20, color: a.color }}>{a.icon}</Text>
              </View>
              <Text style={styles.actionLabel}>{a.label}</Text>
            </TouchableOpacity>
          ))}
        </View>

        {/* ── Cards strip ── */}
        {cardCount > 0 && (
          <TouchableOpacity onPress={() => navigation.navigate('Cards')} activeOpacity={0.85}>
            <LinearGradient colors={['#7c6ff7', '#4facfe']} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}
              style={styles.cardStrip}>
              <Text style={{ fontSize: 22 }}>💳</Text>
              <View style={{ flex: 1 }}>
                <Text style={styles.cardStripTitle}>Virtual Cards</Text>
                <Text style={styles.cardStripSub}>{cardCount} card{cardCount !== 1 ? 's' : ''} active</Text>
              </View>
              <Text style={{ color: 'rgba(255,255,255,0.7)', fontSize: 20 }}>›</Text>
            </LinearGradient>
          </TouchableOpacity>
        )}

        {/* ── Token list ── */}
        {tokens.length > 0 && (
          <Card style={{ marginTop: SPACING.md }}>
            <View style={styles.sectionHead}>
              <Text style={styles.sectionLabel}>ERC-20 Tokens</Text>
              <TouchableOpacity onPress={() => navigation.navigate('Tokens')}>
                <Text style={{ color: COLORS.accent, fontSize: 12 }}>Manage →</Text>
              </TouchableOpacity>
            </View>
            {tokens.slice(0, 4).map((tk, i) => (
              <View key={tk.id} style={[styles.tokenRow, i < tokens.length - 1 && i < 3 && { borderBottomWidth: 1, borderBottomColor: COLORS.border }]}>
                <View style={styles.tokenAvatar}>
                  <Text style={{ fontSize: 10, fontWeight: '800', color: COLORS.accent }}>{tk.symbol.slice(0, 3).toUpperCase()}</Text>
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={styles.tokenSymbol}>{tk.symbol}</Text>
                  <Text style={styles.tokenName}>{tk.name}</Text>
                </View>
                <Text style={{ color: COLORS.textDim, fontSize: 12 }}>ERC-20</Text>
              </View>
            ))}
            {tokens.length > 4 && (
              <TouchableOpacity style={{ paddingVertical: 10, alignItems: 'center' }} onPress={() => navigation.navigate('Tokens')}>
                <Text style={{ color: COLORS.accent, fontSize: 13 }}>+{tokens.length - 4} more tokens</Text>
              </TouchableOpacity>
            )}
          </Card>
        )}

        {/* ── No wallet state ── */}
        {!activeWallet && !loading && (
          <Card style={{ alignItems: 'center', paddingVertical: 32, marginTop: SPACING.md }}>
            <Text style={{ fontSize: 52, marginBottom: 12 }}>👛</Text>
            <Text style={styles.emptyTitle}>Create Your First Wallet</Text>
            <Text style={styles.emptyText}>Generate a BIP39 seed phrase wallet or import an existing one.</Text>
            <View style={{ flexDirection: 'row', gap: 10, marginTop: SPACING.md }}>
              <TouchableOpacity style={styles.emptyBtn} onPress={() => navigation.navigate('CreateWallet')}>
                <Text style={{ color: COLORS.accent, fontWeight: '700' }}>+ Create</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.emptyBtn} onPress={() => navigation.navigate('ImportWallet')}>
                <Text style={{ color: COLORS.accent, fontWeight: '700' }}>Import</Text>
              </TouchableOpacity>
            </View>
          </Card>
        )}
      </ScrollView>
    </SafeAreaView>
  )
}

const styles = StyleSheet.create({
  safe:   { flex: 1, backgroundColor: COLORS.bg },
  // paddingBottom accounts for bottom tab bar height
  scroll: { padding: SPACING.md, paddingBottom: Platform.OS === 'ios' ? 100 : 80 },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: SPACING.md },
  greeting:   { fontSize: 22, fontWeight: '800', color: COLORS.text, letterSpacing: -0.5 },
  walletAddr: { fontSize: 12, color: COLORS.textMuted, fontFamily: 'monospace', marginTop: 2 },
  netPill:  { flexDirection: 'row', alignItems: 'center', gap: 6, borderRadius: 100, paddingHorizontal: 12, paddingVertical: 6, borderWidth: 1, borderColor: COLORS.border2 },
  netDot:   { width: 7, height: 7, borderRadius: 4 },
  netName:  { fontSize: 12, fontWeight: '700' },
  balCard: {
    borderRadius: RADIUS.xl, padding: SPACING.lg, marginBottom: SPACING.md,
    borderWidth: 1, borderColor: 'rgba(124,111,247,0.2)', minHeight: 160,
    position: 'relative', overflow: 'hidden',
  },
  balGlow: { position: 'absolute', top: -40, right: -40, width: 160, height: 160, borderRadius: 80 },
  balLabel:  { fontSize: 11, fontWeight: '700', color: COLORS.textMuted, textTransform: 'uppercase', letterSpacing: 1, marginBottom: 6 },
  balValue:  { fontSize: 36, fontWeight: '800', color: COLORS.text, letterSpacing: -1, fontFamily: Platform.OS === 'ios' ? 'Courier New' : 'monospace' },
  balSymbol: { fontSize: 14, color: COLORS.textMuted, marginTop: 2 },
  balUSD:    { fontSize: 15, color: COLORS.textMuted, marginTop: 4 },
  priceTag:  { position: 'absolute', top: SPACING.md, right: SPACING.md, fontSize: 11, color: COLORS.textMuted, backgroundColor: 'rgba(0,0,0,0.3)', borderRadius: 8, paddingHorizontal: 8, paddingVertical: 4 },
  walletPill: { backgroundColor: 'rgba(255,255,255,0.07)', borderRadius: 100, paddingHorizontal: 12, paddingVertical: 5, marginRight: 8 },
  createWalletBtn: { backgroundColor: 'rgba(124,111,247,0.35)', borderRadius: RADIUS.md, paddingHorizontal: 18, paddingVertical: 10 },
  actionsGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10, marginBottom: SPACING.md },
  actionBtn:   { width: '22%', alignItems: 'center', paddingVertical: 12 },
  actionIcon:  { width: 48, height: 48, borderRadius: 14, justifyContent: 'center', alignItems: 'center', marginBottom: 6 },
  actionLabel: { fontSize: 11, color: COLORS.textMuted, fontWeight: '600', textAlign: 'center' },
  cardStrip: { borderRadius: RADIUS.lg, padding: 16, flexDirection: 'row', alignItems: 'center', gap: 12, marginBottom: SPACING.md },
  cardStripTitle: { color: '#fff', fontWeight: '800', fontSize: 15 },
  cardStripSub:   { color: 'rgba(255,255,255,0.7)', fontSize: 12, marginTop: 2 },
  sectionHead:  { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 },
  sectionLabel: { fontSize: 11, fontWeight: '700', letterSpacing: 1, textTransform: 'uppercase', color: COLORS.textMuted },
  tokenRow:     { flexDirection: 'row', alignItems: 'center', paddingVertical: 10, gap: 12 },
  tokenAvatar:  { width: 36, height: 36, borderRadius: 10, backgroundColor: COLORS.surface3, justifyContent: 'center', alignItems: 'center' },
  tokenSymbol:  { fontSize: 14, fontWeight: '700', color: COLORS.text },
  tokenName:    { fontSize: 11, color: COLORS.textMuted, marginTop: 1 },
  emptyTitle: { fontSize: 18, fontWeight: '700', color: COLORS.text, marginBottom: 8 },
  emptyText:  { color: COLORS.textMuted, textAlign: 'center', lineHeight: 20 },
  emptyBtn:   { paddingHorizontal: 24, paddingVertical: 12, backgroundColor: COLORS.accentDim, borderRadius: RADIUS.md, borderWidth: 1, borderColor: 'rgba(124,111,247,0.3)' },
})
