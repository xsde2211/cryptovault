// src/screens/main/SettingsScreen.js
import React, { useState } from 'react'
import {
  View, Text, ScrollView, TouchableOpacity,
  StyleSheet, Alert as RNAlert, Switch,
} from 'react-native'
import { SafeAreaView } from 'react-native-safe-area-context'
import { useNavigation } from '@react-navigation/native'
import * as Clipboard from 'expo-clipboard'
import { signOut } from '../../services/supabase/authService'
import { deleteWallet } from '../../services/supabase/walletDbService'
import { shortenAddress } from '../../services/blockchain/walletService'
import { useApp } from '../../context/AppContext'
import { getNetwork, NETWORKS } from '../../utils/networks'
import { COLORS, SPACING, RADIUS } from '../../utils/theme'
import { Card, Badge } from '../../components/UI'
import Toast from 'react-native-toast-message'

export default function SettingsScreen() {
  const navigation = useNavigation()
  const { user, wallets, activeWallet, activeNetwork, setActiveWallet, setActiveNetwork, loadWallets, prefs, updatePrefs } = useApp()
  const [signingOut, setSigningOut] = useState(false)

  const handleSignOut = () => {
    RNAlert.alert('Sign Out', 'Are you sure you want to sign out?', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Sign Out', style: 'destructive', onPress: async () => {
        setSigningOut(true)
        try { await signOut() } catch (err) { Toast.show({ type: 'error', text1: err.message }) }
        finally { setSigningOut(false) }
      }},
    ])
  }

  const handleDeleteWallet = (wallet) => {
    RNAlert.alert(
      'Delete Wallet',
      `Remove ${shortenAddress(wallet.address)}?\n\nBack up your seed phrase first — this cannot be undone.`,
      [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Delete', style: 'destructive', onPress: async () => {
          try { await deleteWallet(wallet.id); await loadWallets(); Toast.show({ type: 'success', text1: 'Wallet removed' }) }
          catch (err) { Toast.show({ type: 'error', text1: err.message }) }
        }},
      ]
    )
  }

  const SettingRow = ({ icon, label, value, onPress, danger, right, badge }) => (
    <TouchableOpacity style={styles.row} onPress={onPress} disabled={!onPress} activeOpacity={onPress ? 0.7 : 1}>
      <Text style={styles.rowIcon}>{icon}</Text>
      <View style={{ flex: 1 }}>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
          <Text style={[styles.rowLabel, danger && { color: COLORS.danger }]}>{label}</Text>
          {badge && <Badge label={badge} type="accent" />}
        </View>
        {value && <Text style={styles.rowValue}>{value}</Text>}
      </View>
      {right || (onPress && <Text style={{ color: COLORS.textMuted, fontSize: 18 }}>›</Text>)}
    </TouchableOpacity>
  )

  const Divider = () => <View style={styles.divider} />
  const SectionLabel = ({ title }) => <Text style={styles.sectionLabel}>{title}</Text>

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <ScrollView contentContainerStyle={styles.scroll}>
        <Text style={styles.pageTitle}>Settings</Text>

        {/* ── Account ── */}
        <SectionLabel title="Account" />
        <Card style={styles.card}>
          <SettingRow icon="📧" label="Email"        value={user?.email || '—'} />
          <Divider />
          <SettingRow icon="🪪" label="KYC / Identity Verification" onPress={() => navigation.navigate('KYC')} badge="Required for cards" />
        </Card>

        {/* ── Wallets ── */}
        <SectionLabel title="EVM Wallets (ETH / BNB / Polygon)" />
        <Card style={styles.card}>
          {wallets.map((w, i) => (
            <View key={w.id}>
              <View style={styles.walletRow}>
                <View style={styles.walletAvatar}>
                  <Text style={{ color: COLORS.accent, fontSize: 10, fontWeight: '800' }}>{w.address.slice(2, 4).toUpperCase()}</Text>
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={styles.walletAddr} numberOfLines={1}>{shortenAddress(w.address)}</Text>
                  {activeWallet?.id === w.id && <Text style={{ fontSize: 10, color: COLORS.success, fontWeight: '700' }}>● Active</Text>}
                </View>
                <TouchableOpacity style={styles.iconBtn} onPress={async () => { await Clipboard.setStringAsync(w.address); Toast.show({ type: 'success', text1: 'Copied!' }) }}>
                  <Text>📋</Text>
                </TouchableOpacity>
                {activeWallet?.id !== w.id && (
                  <TouchableOpacity style={[styles.iconBtn, { marginLeft: 4 }]} onPress={() => setActiveWallet(w)}>
                    <Text style={{ color: COLORS.accent, fontSize: 11, fontWeight: '700' }}>Use</Text>
                  </TouchableOpacity>
                )}
                <TouchableOpacity style={[styles.iconBtn, { marginLeft: 4 }]} onPress={() => handleDeleteWallet(w)}>
                  <Text>🗑</Text>
                </TouchableOpacity>
              </View>
              {i < wallets.length - 1 && <Divider />}
            </View>
          ))}
          <Divider />
          <SettingRow icon="➕" label="Create EVM Wallet"  onPress={() => navigation.navigate('CreateWallet')} />
          <Divider />
          <SettingRow icon="📥" label="Import EVM Wallet"  onPress={() => navigation.navigate('ImportWallet')} />
        </Card>

        {/* ── TRON ── */}
        <SectionLabel title="TRON Wallet" />
        <Card style={styles.card}>
          <SettingRow icon="◈" label="TRON Wallet (TRX / TRC-20)" onPress={() => navigation.navigate('TRON')} badge="New" />
        </Card>

        {/* ── Network ── */}
        <SectionLabel title="Active Network" />
        <Card style={styles.card}>
          {Object.values(NETWORKS).map((n, i, arr) => (
            <View key={n.id}>
              <TouchableOpacity style={styles.netRow} onPress={() => setActiveNetwork(n.id)}>
                <View style={[styles.netDot, { backgroundColor: n.color }]} />
                <View style={{ flex: 1 }}>
                  <Text style={[styles.rowLabel, activeNetwork === n.id && { color: n.color }]}>{n.name}</Text>
                  {n.isTestnet && <Text style={{ fontSize: 10, color: COLORS.warning, fontWeight: '700' }}>TESTNET</Text>}
                </View>
                {activeNetwork === n.id && <Text style={{ color: n.color, fontSize: 16 }}>✓</Text>}
              </TouchableOpacity>
              {i < arr.length - 1 && <Divider />}
            </View>
          ))}
        </Card>

        {/* ── Business ── */}
        <SectionLabel title="Business" />
        <Card style={styles.card}>
          <SettingRow icon="🏪" label="Merchant QR Code"        onPress={() => navigation.navigate('Merchant')} badge="New" />
          <Divider />
          <SettingRow icon="🏪" label="P2P Marketplace"         onPress={() => navigation.navigate('P2P')} />
          <Divider />
          <View style={styles.row}>
            <Text style={styles.rowIcon}>💼</Text>
            <View style={{ flex: 1 }}>
              <Text style={styles.rowLabel}>Business KYC Mode</Text>
              <Text style={styles.rowValue}>Enable merchant / business features</Text>
            </View>
            <Switch
              value={prefs.businessMode || false}
              onValueChange={v => updatePrefs({ businessMode: v })}
              trackColor={{ false: COLORS.surface3, true: COLORS.accent }}
              thumbColor="#fff"
            />
          </View>
        </Card>

        {/* ── Cards ── */}
        <SectionLabel title="Cards" />
        <Card style={styles.card}>
          <SettingRow icon="💳" label="Virtual Cards"             onPress={() => navigation.navigate('Cards')} />
          <Divider />
          <SettingRow icon="🪪" label="Complete KYC for Cards"   onPress={() => navigation.navigate('KYC')} />
        </Card>

        {/* ── Preferences ── */}
        <SectionLabel title="Preferences" />
        <Card style={styles.card}>
          <View style={styles.row}>
            <Text style={styles.rowIcon}>🙈</Text>
            <View style={{ flex: 1 }}>
              <Text style={styles.rowLabel}>Hide Balances</Text>
            </View>
            <Switch
              value={prefs.hideBalances}
              onValueChange={v => updatePrefs({ hideBalances: v })}
              trackColor={{ false: COLORS.surface3, true: COLORS.accent }}
              thumbColor="#fff"
            />
          </View>
        </Card>

        {/* ── More ── */}
        <SectionLabel title="Assets & History" />
        <Card style={styles.card}>
          <SettingRow icon="🪙" label="Manage Tokens"      onPress={() => navigation.navigate('Tokens')} />
          <Divider />
          <SettingRow icon="🖼️" label="NFT Gallery"         onPress={() => navigation.navigate('NFTs')} />
          <Divider />
          <SettingRow icon="⭐" label="Watchlist"           onPress={() => navigation.navigate('Watchlist')} />
          <Divider />
          <SettingRow icon="📋" label="Transaction History" onPress={() => navigation.navigate('Transactions')} />
        </Card>

        {/* ── Sign Out ── */}
        <Card style={[styles.card, { marginBottom: SPACING.xl }]}>
          <SettingRow icon="🚪" label={signingOut ? 'Signing out…' : 'Sign Out'} onPress={handleSignOut} danger />
        </Card>

        <Text style={styles.version}>CryptoVault v2.0.0 · Non-Custodial · Open Source</Text>
      </ScrollView>
    </SafeAreaView>
  )
}

const styles = StyleSheet.create({
  safe:    { flex: 1, backgroundColor: COLORS.bg },
  scroll:  { padding: SPACING.md, paddingBottom: 50 },
  pageTitle: { fontSize: 26, fontWeight: '800', color: COLORS.text, marginBottom: SPACING.lg },
  sectionLabel: { fontSize: 11, fontWeight: '700', letterSpacing: 1.2, textTransform: 'uppercase', color: COLORS.textMuted, marginBottom: 8, marginTop: 4, paddingHorizontal: 2 },
  card: { padding: 0, overflow: 'hidden', marginBottom: SPACING.md },
  row:  { flexDirection: 'row', alignItems: 'center', paddingHorizontal: SPACING.md, paddingVertical: 14, gap: 12 },
  rowIcon:  { fontSize: 18, width: 24, textAlign: 'center' },
  rowLabel: { fontSize: 15, color: COLORS.text, fontWeight: '500' },
  rowValue: { fontSize: 12, color: COLORS.textMuted, marginTop: 1 },
  divider:  { height: 1, backgroundColor: COLORS.border, marginHorizontal: SPACING.md },
  walletRow: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: SPACING.md, paddingVertical: 12, gap: 10 },
  walletAvatar: { width: 36, height: 36, borderRadius: 10, backgroundColor: 'rgba(124,111,247,0.15)', borderWidth: 1, borderColor: 'rgba(124,111,247,0.3)', justifyContent: 'center', alignItems: 'center' },
  walletAddr: { fontFamily: 'monospace', fontSize: 13, color: COLORS.text, fontWeight: '600' },
  iconBtn: { width: 34, height: 34, borderRadius: 8, backgroundColor: COLORS.surface2, borderWidth: 1, borderColor: COLORS.border, justifyContent: 'center', alignItems: 'center' },
  netRow: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: SPACING.md, paddingVertical: 14, gap: 12 },
  netDot: { width: 10, height: 10, borderRadius: 5 },
  version: { textAlign: 'center', color: COLORS.textDim, fontSize: 12, marginTop: SPACING.md },
})
